import { Component, OnInit } from "@angular/core";
import { WORDS } from "./word-list";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.scss"]
})
export class AppComponent implements OnInit {
  title = "Play the Hangman Game";
  imgNumber: number;
  attempt: number;
  right: number = 0;
  miss: number = 0;
  win: boolean = false;
  loose: boolean = false;
  password: string;
  hiddenPassword: string;
  selectedLetter: string;

  startGame = () => {
    this.password = WORDS[
      Math.floor(Math.random() * WORDS.length)
    ].toUpperCase();
    this.hiddenPassword = Array.prototype.map
      .call(this.password, letter => "-")
      .join("");
    this.imgNumber = 1;
    this.attempt = 6;
    this.right = 0;
    this.miss = 0;
    this.win = false;
    this.loose = false;
    this.hiddenPassword = [...this.password].map(letter => "-").join("");
  };

  handleCheck(letter) {
    console.log("app comp", letter);
    letter.selected = true;
    for (let i = 0; i < this.password.length; i++) {
      if (letter.name === this.password[i]) {
        if (i > 0) {
          this.hiddenPassword = [
            this.hiddenPassword.slice(0, i),
            letter.name,
            this.hiddenPassword.slice(i + 1)
          ].join("");
        } else {
          this.hiddenPassword = [
            letter.name,
            this.hiddenPassword.slice(i + 1)
          ].join("");
        }
        this.right += 1;
        letter.status = "ok";
        if (this.right === this.password.length) {
          this.win = true;
        }
      }
    }
    // letter is incorrect
    if (this.password.search(letter.name) === -1) {
      this.attempt -= 1;
      this.miss += 1;
      this.imgNumber += 1;
      letter.status = "wrong";
      if (this.miss === 6) {
        this.loose = true;
      }
    }
  }

  grammar = () => (this.miss === 1 ? "time" : "times");

  ngOnInit() {
    this.startGame();
  }
}
