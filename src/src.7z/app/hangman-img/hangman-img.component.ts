import { Component, OnChanges, Input } from "@angular/core";
import { AppComponent } from "../app.component";

@Component({
  selector: "app-hangman-img",
  templateUrl: "./hangman-img.component.html",
  styleUrls: ["./hangman-img.component.scss"]
})
export class HangmanImgComponent implements OnChanges {
  @Input() imgNumber: AppComponent;

  imgSrc: string = `assets/img/hangman${this.imgNumber}.jpg`;

  setImgSrc() {
    this.imgSrc = `assets/img/hangman${this.imgNumber}.jpg`;
  }

  ngOnChanges() {
    this.setImgSrc();
  }
}
