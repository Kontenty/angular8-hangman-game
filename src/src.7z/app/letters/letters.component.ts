import { Component, OnInit, EventEmitter, Output } from "@angular/core";

@Component({
  selector: "app-letters",
  templateUrl: "./letters.component.html",
  styleUrls: ["./letters.component.scss"]
})
export class LettersComponent implements OnInit {
  @Output() selectedLetter = new EventEmitter<string>();

  ngOnInit() {}

  alphabet = "abcdefghijklmnopqrstuvwxyz".toUpperCase();
  letters = Array.prototype.map.call(this.alphabet, letter => {
    return { name: letter, selected: false, status: null };
  });

  onSelect = letter => {
    console.log("letter comp  ", letter);
    this.selectedLetter.emit(letter);
  };
}
